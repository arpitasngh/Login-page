

document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();  // Prevent the form from refreshing the page

    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    
    document.getElementById('emailError').textContent = '';
    document.getElementById('passwordError').textContent = '';

    
    if (email && password) {
        
        alert('Login Successful!');  
    } else {
        
        if (!email) {
            document.getElementById('emailError').textContent = 'Email is required.';
            document.getElementById('email').classList.add('error');
        }
        if (!password) {
            document.getElementById('passwordError').textContent = 'Password is required.';
            document.getElementById('password').classList.add('error');
        }
    }
});
